package com.parse.starter;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.parse.GetCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.ParseUser;
import com.parse.SaveCallback;
import com.parse.SignUpCallback;

import static com.google.android.gms.analytics.internal.zzy.e;

public class PatientProfileFillingActivity extends AppCompatActivity {

    EditText fullName;
    EditText email;
    EditText age;
    EditText raddress;
    EditText mobileNumber;
    RadioButton genderradioButton;
    RadioGroup radioGroup;
    ParseUser user;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_details_filling);
        setTitle("Update Profile");

        fullName=(EditText) findViewById(R.id.fullNameEditText);
        email=(EditText) findViewById(R.id.emailEditText);
        age=(EditText)findViewById(R.id.ageEditText);
        raddress=(EditText) findViewById(R.id.raddressEditText);
        mobileNumber=(EditText)findViewById(R.id.mobileNumberEditText);
        radioGroup=(RadioGroup)findViewById(R.id.radioGroup);

    }
    public void showUserList() {
        Intent intent = new Intent(getApplicationContext(), UserListActivity.class);
        startActivity(intent);
    }

    public void doneClicked(View view) {
        Log.i("button","done button clicked");
        final int selectedId = radioGroup.getCheckedRadioButtonId();
        if (fullName.getText().toString().matches("") || email.getText().toString().matches("")
                || age.getText().toString().matches("")|| raddress.getText().toString().matches("")||selectedId==-1) {
            Toast.makeText(this, "All fields are necessary.",Toast.LENGTH_SHORT).show();

        }
        else {
            ParseObject Profile= new ParseObject("Profile");
            user = ParseUser.getCurrentUser();
            Profile.put("username",user.get("username"));
//            String userID = user.getObjectId();

//            ParseQuery<ParseUser> query = ParseUser.getQuery();
//            query.getInBackground(userID, new GetCallback<ParseUser>() {
//                @Override
//                public void done(ParseUser parseUser, ParseException e) {
//                    if (e == null) {
                        Profile.put("fullName", fullName.getText().toString());
            Profile.put("patientOrDoctor", user.get("patientOrDoctor"));
            Profile.put("email",email.getText().toString());
            Profile.put("Age", age.getText().toString());
            Profile.put("Address", raddress.getText().toString());
            Profile.put("Mobile_Number", mobileNumber.getText().toString());

                        genderradioButton = (RadioButton) findViewById(selectedId);

            Profile.put("Gender", genderradioButton.getText().toString());


            Profile.saveInBackground();
                        showUserList();
//                    }
//
//                }
//            });



//            if (user != null) {
//                user.put("fullName", fullName.getText().toString());
//               user.setEmail(email.getText().toString());
//                user.put("Age", age.getText().toString());
//                user.put("Address", raddress.getText().toString());
//                user.put("Mobile_Number", mobileNumber.getText().toString());
//
//                genderradioButton = (RadioButton) findViewById(selectedId);
//
//                user.put("Gender", genderradioButton.getText().toString());
//
//                user.saveInBackground(new SaveCallback() {
//
//                    @Override
//                    public void done(ParseException e) {
//                        if (e == null)
//                            Log.i("Patient Profile update", "Success!!");
//                        else
//                            e.printStackTrace();
//                    }
//                });
//
//
//            }
//            else{
//                Toast.makeText(getApplicationContext(),"No User signed in",Toast.LENGTH_SHORT).show();
//            }
//
       }


    }
}
